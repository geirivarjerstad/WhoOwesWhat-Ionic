YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "ngMidwayTester"
    ],
    "modules": [],
    "allModules": []
} };
});